function repeatedString(s, n) {
  // TODO
}

export { repeatedString };
