function zeroMeansZero(a, b) {
  // TODO
}

export { zeroMeansZero };
