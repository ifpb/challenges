function numberOfLeds(number) {
  // TODO
}

export { numberOfLeds };
