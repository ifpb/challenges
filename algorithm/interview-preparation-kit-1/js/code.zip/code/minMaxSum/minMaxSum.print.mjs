import { minMaxSum } from './minMaxSum.mjs';

console.log(minMaxSum([1, 2, 3, 4, 5]));
console.log([10, 14]);

console.log(minMaxSum([0, 2, 6, 3, 4]));
console.log([9, 15]);

console.log(minMaxSum([10, 23, 61, 37, 41]));
console.log([111, 162]);
