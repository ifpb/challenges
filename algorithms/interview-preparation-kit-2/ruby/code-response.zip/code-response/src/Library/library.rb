class Library
  def Library.sort(codes) 
    codes.sort
  end
end
