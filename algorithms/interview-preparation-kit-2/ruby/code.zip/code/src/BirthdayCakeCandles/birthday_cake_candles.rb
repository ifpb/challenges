class BirthdayCakeCandles
  def BirthdayCakeCandles.candle(array)
    # TODO
  end
end
