class FunnyString
  def FunnyString.check(s) 
    # TODO
  end
end