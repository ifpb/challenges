class Triplets
  def Triplets.compare(input)
    # TODO
  end
end
