class HackerrankInString
  def HackerrankInString.check(s)
    # TODO
  end
end
