class CatAndMouse
  def CatAndMouse.search(catA, catB, ratC)
    # TODO
  end
end
