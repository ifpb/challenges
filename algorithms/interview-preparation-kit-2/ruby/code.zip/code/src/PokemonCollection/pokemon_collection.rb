class PokemonCollection
  def PokemonCollection.notCaptured(pokemons) 
    # TODO
  end
end
