class Valleys
  def Valleys.count(input)
    # TODO
  end
end
