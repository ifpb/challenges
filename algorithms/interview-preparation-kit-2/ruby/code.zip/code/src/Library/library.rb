class Library
  def Library.sort(codes) 
    # TODO
  end
end
