class ApplesAndOranges
  def ApplesAndOranges.count(casaInicio, casaFim, macieira, laranjeira, macas, laranjas)
    # TODO
  end
end
