class CharCode
  def CharCode.sum(input)
    # TODO
  end
end
