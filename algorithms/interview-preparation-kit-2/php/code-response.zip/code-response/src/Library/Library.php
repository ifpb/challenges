<?php

namespace Library;

class Library
{
  public static function sort($codes)
  {
    return \sort($codes);
  }
}
