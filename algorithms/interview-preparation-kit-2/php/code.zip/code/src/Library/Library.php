<?php

namespace Library;

class Library
{
  public static function sort($codes)
  {
    // TODO
  }
}
