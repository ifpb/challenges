<?php

namespace BirthdayCakeCandles;

class BirthdayCakeCandles
{
  public static function blowOut($candles)
  {
    // TODO
  }
}
