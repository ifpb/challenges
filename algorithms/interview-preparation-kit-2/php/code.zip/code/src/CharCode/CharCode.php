<?php

namespace CharCode;

class CharCode
{
  public static function sum($s)
  {
    // TODO
  }
}
