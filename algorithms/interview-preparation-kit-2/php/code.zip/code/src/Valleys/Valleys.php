<?php

namespace Valleys;

class Valleys
{

  public static function count($steps)
  {
    // TODO
  }
}
