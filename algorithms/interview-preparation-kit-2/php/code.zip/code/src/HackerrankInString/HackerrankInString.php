<?php

namespace HackerrankInString;

class HackerrankInString
{
  public static function check($s)
  {
    // TODO
  }
}
