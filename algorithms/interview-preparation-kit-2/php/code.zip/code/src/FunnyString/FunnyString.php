<?php

namespace FunnyString;

class FunnyString
{
  public static function check($s)
  {
    // TODO
  }
}
