<?php

namespace PokemonCollection;

class PokemonCollection
{
  public static function notCaptured($pokemons)
  {
    // TODO
  }
}
