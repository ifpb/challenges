<?php

namespace ApplesAndOranges;

class ApplesAndOranges
{
  public static function count($s, $t, $a, $b, $apples, $oranges)
  {
    // TODO
  }
}
