<?php

namespace CatAndMouse;

class CatAndMouse
{
  public static function result($x, $y, $z)
  {
    // TODO
  }
}
