function addingCharCode(s) {
  // TODO
}

export { addingCharCode };
