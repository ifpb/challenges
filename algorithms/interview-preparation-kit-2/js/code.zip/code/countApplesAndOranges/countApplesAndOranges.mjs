function countApplesAndOranges(s, t, a, b, apples, oranges) {
  // TODO
}

export { countApplesAndOranges };
