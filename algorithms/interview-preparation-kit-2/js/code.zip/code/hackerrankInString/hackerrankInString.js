function hackerrankInString(s) {
  // TODO
}

export { hackerrankInString };
