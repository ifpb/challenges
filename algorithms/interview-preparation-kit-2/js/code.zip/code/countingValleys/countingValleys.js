function countingValleys(s) {
  // TODO
}

export { countingValleys };
