function catAndMouse(x, y, z) {
  // TODO
}

export { catAndMouse };
