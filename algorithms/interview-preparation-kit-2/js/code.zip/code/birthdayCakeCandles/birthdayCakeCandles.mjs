function birthdayCakeCandles(candles) {
  // TODO
}

export { birthdayCakeCandles };
