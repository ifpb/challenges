function funnyString(s) {
  // TODO
}

export { funnyString };
