function pokemonCollection(pokemons) {
  // TODO
}

export { pokemonCollection };
