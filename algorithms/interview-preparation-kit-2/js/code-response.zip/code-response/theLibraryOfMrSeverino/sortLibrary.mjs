function sortLibrary(codes) {
  return codes.sort((a, b) => a - b);
}

export { sortLibrary };
