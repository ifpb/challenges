<?php

namespace Challenge;

class NumberOfLeds
{

  public static function calc($number)
  {
    // TODO
  }
}
