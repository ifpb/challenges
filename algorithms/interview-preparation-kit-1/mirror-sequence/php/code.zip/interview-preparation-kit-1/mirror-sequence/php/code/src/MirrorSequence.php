<?php

namespace Challenge;

class MirrorSequence
{

  public static function generate($a, $b)
  {
    // TODO
  }

}
