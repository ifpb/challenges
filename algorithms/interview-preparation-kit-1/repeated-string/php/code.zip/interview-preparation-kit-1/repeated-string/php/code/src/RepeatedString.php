<?php

namespace Challenge;

class RepeatedString
{

  public static function calc($s, $n): int
  {
    // TODO
  }

}
