class RepeatedString
  def RepeatedString.repeat(s, n)
    # TODO
  end
end