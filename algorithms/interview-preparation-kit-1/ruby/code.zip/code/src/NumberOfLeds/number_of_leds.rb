class NumberOfLeds
  def NumberOfLeds.leds(num)
    # TODO
  end
end