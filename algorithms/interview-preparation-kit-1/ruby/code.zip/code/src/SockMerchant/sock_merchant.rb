class SockMerchant
  def SockMerchant.count_pair_of_socks(array)
    # TODO
  end
end