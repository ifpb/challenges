class HighestFrequency
  def HighestFrequency.highest(array)  
    # TODO
  end
end