class ArrayStats
  def ArrayStats.stats(arr)
    # TODO
  end
end