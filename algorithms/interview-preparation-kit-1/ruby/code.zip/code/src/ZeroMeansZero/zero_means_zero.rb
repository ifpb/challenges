class ZeroMeansZero
  def ZeroMeansZero.noZero(a, b)
    # TODO
  end
end