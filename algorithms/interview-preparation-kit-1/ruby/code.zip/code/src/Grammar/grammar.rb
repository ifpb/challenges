class Grammar
  def Grammar.spelling(word)
    # TODO
  end
end