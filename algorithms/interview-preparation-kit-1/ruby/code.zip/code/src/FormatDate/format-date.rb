class FormatDate
  def FormatDate.to_string(date)
    # TODO
  end
end