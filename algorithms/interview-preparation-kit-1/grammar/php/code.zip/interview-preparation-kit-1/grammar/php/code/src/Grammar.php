<?php

namespace Challenge;

class Grammar
{
  public static function spelling($word)
  {
    // TODO
  }
}
