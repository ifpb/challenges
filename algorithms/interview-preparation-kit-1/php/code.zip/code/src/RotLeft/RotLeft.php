<?php
namespace RotLeft;

class RotLeft
{

  public static function rot($array, $d)
  {
    // TODO
  }

}
