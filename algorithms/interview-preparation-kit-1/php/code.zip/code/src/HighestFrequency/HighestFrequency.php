<?php

namespace HighestFrequency;

class HighestFrequency
{

  public static function calc($array)
  {
    // TODO
  }
}
