<?php
namespace Vector;

class ArrayUtil
{

  public function __construct($array)
  {
    // TODO
  }

  public function rotLeft($d)
  {
    // TODO
  }

  public function stats()
  {
    // TODO
  }

  public function minMaxSum()
  {
    // TODO
  }

  public function highestFrequency()
  {
    // TODO
  }
}
