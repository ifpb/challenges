<?php
namespace SockMerchant;

class SockMerchant
{
  public static function pairs($socks): int
  {
    // TODO
  }
}
