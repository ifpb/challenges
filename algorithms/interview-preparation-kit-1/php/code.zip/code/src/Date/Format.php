<?php
namespace Date;

class Format
{
  public static function long($date)
  {
    // TODO
  }
}
