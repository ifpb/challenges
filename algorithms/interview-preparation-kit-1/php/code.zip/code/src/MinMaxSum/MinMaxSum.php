<?php
namespace MinMaxSum;

class MinMaxSum
{

  public static function calc($array)
  {
    // TODO
  }
}
