<?php
namespace MirrorSequence;

class MirrorSequence
{

  public static function generate($a, $b)
  {
    // TODO
  }

}
