<?php

namespace ZeroMeansZero;

class ZeroMeansZero
{

  public static function change($a, $b)
  {
    // TODO
  }

}
