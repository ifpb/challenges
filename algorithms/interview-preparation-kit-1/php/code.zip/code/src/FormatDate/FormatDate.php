<?php
namespace FormatDate;

class FormatDate
{
  public static function check($date)
  {
    // TODO
  }
}
