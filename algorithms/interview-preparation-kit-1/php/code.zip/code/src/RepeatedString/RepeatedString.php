<?php
namespace RepeatedString;

class RepeatedString
{

  public static function calc($s, $n): int
  {
    // TODO
  }

}
