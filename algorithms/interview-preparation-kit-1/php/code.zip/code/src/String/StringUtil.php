<?php
namespace String;

class StringUtil
{

  public static function repeatedString($s, $n): int
  {
    // TODO
  }

  public static function mirrorSequence($a, $b)
  {
    // TODO
  }

  public static function zeroMeansZero($a, $b)
  {
    // TODO
  }

  public static function numberOfLeds($number)
  {
    // TODO
  }
}
