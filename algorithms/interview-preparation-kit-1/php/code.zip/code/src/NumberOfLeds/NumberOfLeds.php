<?php
namespace NumberOfLeds;

class NumberOfLeds
{

  public static function calc($number)
  {
    // TODO
  }
}
