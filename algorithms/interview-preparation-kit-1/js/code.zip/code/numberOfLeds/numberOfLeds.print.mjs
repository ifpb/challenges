import { numberOfLeds } from './numberOfLeds.mjs';

console.log(numberOfLeds('1'));
console.log(2);

console.log(numberOfLeds('2'));
console.log(5);

console.log(numberOfLeds('115380'));
console.log(27);

console.log(numberOfLeds('2819311'));
console.log(29);

console.log(numberOfLeds('23456'));
console.log(25);
