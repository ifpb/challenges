function sockMerchant(socks) {
  // TODO
}

export { sockMerchant };
