function longFormat(date) {
  // TODO
}

export { longFormat };
