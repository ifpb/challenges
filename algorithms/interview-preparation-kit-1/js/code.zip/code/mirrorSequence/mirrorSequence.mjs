function mirrorSequence(a, b) {
  // TODO
}

export { mirrorSequence };
