function minMaxSum(arr) {
  // TODO
}

export { minMaxSum };
