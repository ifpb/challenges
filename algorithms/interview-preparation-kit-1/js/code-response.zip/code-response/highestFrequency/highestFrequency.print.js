import { highestFrequency } from './highestFrequency.js';

console.log(highestFrequency([1, 4, 4, 4, 5, 3]));
console.log(4);

console.log(highestFrequency([1, 1, 1, 4, 5, 3]));
console.log(1);

console.log(highestFrequency([1, 2, 3, 4, 5, 4, 3, 2, 1, 3, 4]));
console.log(3);
