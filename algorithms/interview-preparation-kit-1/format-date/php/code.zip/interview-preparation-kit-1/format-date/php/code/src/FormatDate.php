<?php

namespace Challenge;

class FormatDate
{
  public static function check($date)
  {
    // TODO
  }
}
