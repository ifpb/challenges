<?php

namespace Challenge;

class HighestFrequency
{

  public static function calc($array)
  {
    // TODO
  }
}
