function highestFrequency(types) {
  // TODO
}

export { highestFrequency };
