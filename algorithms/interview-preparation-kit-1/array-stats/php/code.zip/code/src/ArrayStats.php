<?php

namespace ArrayStats;

class ArrayStats
{

  public static function stats($array)
  {
    // TODO
  }
  
}
