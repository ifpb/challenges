<?php

namespace Challenge;

class ArrayStats
{

  public static function stats($array)
  {
    // TODO
  }
  
}
