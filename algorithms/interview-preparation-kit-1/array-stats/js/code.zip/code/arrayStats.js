function stats(arr) {
  // TODO
}

export { stats };
