<?php

namespace Challenge;

class SockMerchant
{
  public static function pairs($socks): int
  {
    // TODO
  }
}
