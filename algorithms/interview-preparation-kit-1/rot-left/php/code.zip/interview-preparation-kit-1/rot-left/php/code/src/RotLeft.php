<?php

namespace Challenge;

class RotLeft
{

  public static function rot($array, $d)
  {
    // TODO
  }

}
