class RotLeft
  def RotLeft.rotate(arr, n)
    # TODO
  end
end