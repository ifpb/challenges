function rotLeft(a, d) {
  // TODO
}

export { rotLeft };
