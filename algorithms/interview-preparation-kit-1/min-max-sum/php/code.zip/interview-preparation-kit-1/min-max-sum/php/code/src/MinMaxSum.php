<?php

namespace Challenge;

class MinMaxSum
{

  public static function calc($array)
  {
    // TODO
  }
}
