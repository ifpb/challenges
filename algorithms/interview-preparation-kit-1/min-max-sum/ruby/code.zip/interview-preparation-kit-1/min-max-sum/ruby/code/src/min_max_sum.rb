class MinMaxSum
  def MinMaxSum.calc(array)
    # TODO
  end
end