import { zeroMeansZero } from './zeroMeansZero.js';

console.log(zeroMeansZero(7, 8));
console.log('15');

console.log(zeroMeansZero(15, 5));
console.log('2');

console.log(zeroMeansZero(99, 6));
console.log('15');
