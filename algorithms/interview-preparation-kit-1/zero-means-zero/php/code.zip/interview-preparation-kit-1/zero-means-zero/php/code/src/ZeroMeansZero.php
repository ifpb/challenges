<?php

namespace Challenge;

class ZeroMeansZero
{

  public static function change($a, $b)
  {
    // TODO
  }

}
