<?php

namespace Squares;

class Squares
{
  // TODO
}
