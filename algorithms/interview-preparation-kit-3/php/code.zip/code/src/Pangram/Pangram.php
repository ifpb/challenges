<?php

namespace Pangram;

class Pangram
{
  public static function check($sentence)
  {
    // TODO
  }
}
