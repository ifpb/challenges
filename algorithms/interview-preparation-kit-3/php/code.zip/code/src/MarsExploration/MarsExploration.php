<?php

namespace MarsExploration;

class MarsExploration
{
  public static function check($message)
  {
    // TODO
  }
}
