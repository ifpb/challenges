<?php

namespace Raindrops;

class Raindrops
{

  public static function convert($number)
  {
    // TODO
  }
}