<?php

namespace Anagram;

class Anagram
{
  public static function check($a, $b)
  {
    // TODO
  }
}
