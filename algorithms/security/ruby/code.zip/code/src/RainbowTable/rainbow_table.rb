# use MD5.rb
# use array_combination.rb
require 'digest'

class RainbowTable
  # TODO
end
