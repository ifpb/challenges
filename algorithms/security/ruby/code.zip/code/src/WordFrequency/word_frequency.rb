class WordFrequency
  def WordFrequency.wordFrequency(input)
    # TODO
  end
end
