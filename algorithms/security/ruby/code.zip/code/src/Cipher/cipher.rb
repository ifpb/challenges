class Cipher 
  # TODO
end
